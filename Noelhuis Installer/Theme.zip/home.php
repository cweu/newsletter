<?php

/*

  @package OnWeb Noelhuis

  Template Name: Front page

*/

?>

<?php get_header(); ?>

<?php get_footer();  ?>
